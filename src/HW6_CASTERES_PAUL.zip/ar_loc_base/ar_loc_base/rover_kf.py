#!/usr/bin/env python3

from rclpy.node import Node
import rclpy
from numpy import *
from numpy.linalg import inv
from math import pi, sin, cos
from visualization_msgs.msg import Marker, MarkerArray
from geometry_msgs.msg import PoseWithCovarianceStamped, PoseStamped
import threading
from rover_driver_base.rover_kinematics import RoverKinematics
from ar_loc_base.rover_odo import RoverOdo

class RoverKF(RoverOdo):
    def __init__(self, node, initial_pose, initial_uncertainty):
        super().__init__(node, initial_pose, initial_uncertainty)
        self.X = mat(vstack(initial_pose))
        self.P = mat(diag(initial_uncertainty))
        self.ellipse_pub = node.create_publisher(Marker, "~/ellipse", 1)
        self.pose_with_cov_pub = node.create_publisher(PoseWithCovarianceStamped, "~/pose_with_covariance", 1)
        self.P = eye(3) * 1e-6

    def getRotationFromWorldToRobot(self):
        return self.getRotation(-self.X[2, 0])

    def predict(self, logger, motor_state, drive_cfg, encoder_precision):
        self.lock.acquire()
        if self.first_run:
            self.motor_state.copy(motor_state)
            self.first_run = False
            self.lock.release()
            return (self.X, self.P)
        iW = self.prepare_inversion_matrix(drive_cfg)
        S = self.prepare_displacement_matrix(self.motor_state, motor_state, drive_cfg)
        self.motor_state.copy(motor_state)

        n = iW.shape[0]
        Q = eye(n) * 1e-4
        Qu = eye(12) * encoder_precision * 1e-1

        theta = self.X[2, 0]
        Rtheta = mat([[cos(theta), -sin(theta), 0],
                      [sin(theta), cos(theta), 0],
                      [0, 0, 1]])

        delta_x, delta_y = (iW @ S)[:2]
        B = Rtheta @ iW
        A = eye(n)
        A[0, 2] = -sin(theta) * delta_x - cos(theta) * delta_y
        A[1, 2] = cos(theta) * delta_x - sin(theta) * delta_y

        self.X += Rtheta @ iW @ S
        self.P = A @ self.P @ A.T + B @ Qu @ B.T + Q
        self.lock.release()
        return (self.X, self.P)

    def update_ar(self, logger, Z, L, uncertainty):
        self.lock.acquire()
        theta = self.X[2, 0]
        Rtheta = mat([[cos(theta), -sin(theta), 0],
                      [sin(theta), cos(theta), 0],
                      [0, 0, 1]])

        Lx, Ly = L[0, 0], L[1, 0]
        x, y = self.X[0, 0], self.X[1, 0]

        delta_x = Lx - x
        delta_y = Ly - y

        H = array([[-cos(theta), -sin(theta), -sin(theta) * delta_x + cos(theta) * delta_y],
                   [sin(theta), -cos(theta), -cos(theta) * delta_x - sin(theta) * delta_y]])

        K = self.P @ H.T @ inv(H @ self.P @ H.T + uncertainty * eye(2))
        self.X += K @ (Z - (Rtheta.T[0:2, 0:2] @ (L - self.X[0:2])))
        self.P = (eye(self.P.shape[0]) - K @ H) @ self.P

        self.lock.release()
        return (self.X, self.P)

    def update_compass(self, logger, Z, uncertainty):
        self.lock.acquire()
        H = array([[0, 0, 1]])

        theta_estimated = self.X[2, 0]
        innovation = array([[(Z - theta_estimated + pi) % (2 * pi) - pi]])
        S = H @ self.P @ H.T + uncertainty
        K = self.P @ H.T @ inv(S)

        self.X += K @ innovation
        self.X[2, 0] = (self.X[2, 0] + pi) % (2 * pi) - pi
        self.P = (eye(self.P.shape[0]) - K @ H) @ self.P

        self.lock.release()
        return (self.X, self.P)

    def publish(self, pose_pub, odom_pub, target_frame, stamp, child_frame):
        pose_simple = super().publish(pose_pub, odom_pub, target_frame, stamp, child_frame)
        pose = PoseWithCovarianceStamped()
        pose.header = pose_simple.header
        pose.pose.pose = pose_simple.pose

        C = [0.] * 36
        C[0] = self.P[0, 0]
        C[1] = self.P[0, 1]
        C[5] = self.P[0, 2]
        C[6] = self.P[1, 0]
        C[7] = self.P[1, 1]
        C[11] = self.P[1, 2]
        C[30] = self.P[2, 0]
        C[31] = self.P[2, 1]
        C[35] = self.P[2, 2]

        pose.pose.covariance = C
        self.pose_with_cov_pub.publish(pose)

        marker = Marker()
        marker.header = pose.header
        marker.ns = "kf_uncertainty"
        marker.id = 1
        marker.type = Marker.CYLINDER
        marker.action = Marker.ADD
        marker.pose = pose.pose.pose
        marker.scale.x = 3 * sqrt(self.P[0, 0])
        marker.scale.y = 3 * sqrt(self.P[1, 1])
        marker.scale.z = 0.1
        marker.color.a = 1.0
        marker.color.r = 1.0
        marker.color.g = 1.0
        marker.color.b = 0.0
        self.ellipse_pub.publish(marker)
