import os
import yaml
import sys

import ament_index_python.packages
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, LogInfo, ExecuteProcess
from launch.substitutions import LaunchConfiguration
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
from launch_ros.actions import ComposableNodeContainer
from launch_ros.descriptions import ComposableNode



def generate_launch_description():
    actions = []

    #! ------------- SLAM ARGUMENTS ------------------
    use_sim_time = LaunchConfiguration('use_sim_time')
    slam_params_file = LaunchConfiguration('slam_params_file')

    declare_use_sim_time_argument = DeclareLaunchArgument(
        'use_sim_time',
        default_value='false',
        description='Use simulation/Gazebo clock')

    declare_slam_params_file_cmd = DeclareLaunchArgument(
        'slam_params_file',
        default_value=os.path.join(
            get_package_share_directory("occgrid_planner_base"),
            'mapper_params_tb_sync.yaml'),
        description='Full path to the ROS2 parameters file to use for the slam_toolbox node')

    actions.append(declare_use_sim_time_argument)
    actions.append(declare_slam_params_file_cmd)

    #! ------------- LIDAR ARGUMENTS ------------------
    channel_type =  LaunchConfiguration('channel_type', default='serial')
    serial_port = LaunchConfiguration('serial_port', default='/dev/rplidar')
    serial_baudrate = LaunchConfiguration('serial_baudrate', default='115200')
    frame_id = LaunchConfiguration('frame_id', default='rplidar')
    inverted = LaunchConfiguration('inverted', default='false')
    angle_compensate = LaunchConfiguration('angle_compensate', default='true')
    scan_mode = LaunchConfiguration('scan_mode', default='Sensitivity')

    #! ------------- KOBUKI NODE ------------------
    share_dir_kobuki = get_package_share_directory('kobuki_node')
    params_file = os.path.join(share_dir_kobuki, 'config', 'kobuki_node_params.yaml')
    with open(params_file, 'r') as f:
        params = yaml.safe_load(f)['kobuki_ros_node']['ros__parameters']

    kobuki_ros_node = Node(
        package='kobuki_node',
        executable='kobuki_ros_node',
        output='both',
        parameters=[params])
    actions.append(kobuki_ros_node)

    #! ------------- SLAM TOOLBOX NODE ------------------
    slam_toolbox_node = Node(
        parameters=[slam_params_file, {'use_sim_time': use_sim_time}],
        package='slam_toolbox',
        executable='sync_slam_toolbox_node',
        name='slam_toolbox',
        output='screen')
    actions.append(slam_toolbox_node)

    #! ------------- PLANNER NODES ------------------
    occgrid_node = Node(
        package='occgrid_planner_base',
        executable='occgrid_planner_base',
        name='occgrid_planner',
        parameters=[
            {'~/neighbourhood': 8},
            {'~/base_frame': 'base_link'},
            {'~/debug': False},
            {'~/headless': True},
        ],
        remappings=[
            ('~/occ_grid', '/map'),
            ('~/goal', '/goal_pose'),
        ],
        output='screen')
    actions.append(occgrid_node)

    path_optimizer_node = Node(
        package='occgrid_planner_base',
        executable='path_optimizer_base',
        name='path_optimizer',
        parameters=[
            {'~/max_acceleration': 0.3},
            {'~/max_braking': 0.1},
            {'~/velocity': 0.35},
        ],
        remappings=[
            ('~/path', '/occgrid_planner/path'),
        ],
        output='screen')
    actions.append(path_optimizer_node)

    path_follower_node = Node(
        package='occgrid_planner_base',
        executable='path_follower_base',
        name='path_follower',
        parameters=[
            {'~/Kx': 1.0},
            {'~/Ky': 1.0},
            {'~/Ktheta': 5.0},
            {'~/max_rot_speed': 1.0},
            {'~/max_velocity': 0.35},
            {'~/max_y_error': 0.1},
            {'~/max_error': 0.5},
            {'~/look_ahead': 0.6},
            {'~/base_frame': 'base_link'},
        ],
        remappings=[
            ('~/traj', '/path_optimizer/trajectory'),
            ('~/twistCommand', '/mux/autoCommand'),
            ('~/goal', '/goal_pose'),
        ],
        output='screen')
    actions.append(path_follower_node)

    #! ------------- COLLISION AVOIDANCE NODE ------------------
    collision_node = Node(
        package='collision_avoidance_base',
        executable='collision_avoidance_base',
        name='collision_avoidance',
        parameters=[
            {'~/safety_diameter': 0.23},
            {'~/ignore_diameter': 1.0},
            {'~/max_velocity': 0.35},
            {'~/only_forward': False},
        ],
        remappings=[
            # ('~/clouds', '/points'),
            ('~/scans', '/scan'),
            ('~/vel_input', '/cmd_mux/obstacle'),
            ('~/vel_output', '/commands/velocity'),
        ],
        output='screen')
    actions.append(collision_node)
    #! ----------------------- LIDAR NODE --------------------------
    lidar1 = Node(
            package='rplidar_ros',
            executable='rplidar_node',
            name='rplidar_node',
            parameters=[{'channel_type':channel_type,
                         'serial_port': serial_port,
                         'serial_baudrate': serial_baudrate,
                         'frame_id': frame_id,
                         'inverted': inverted,
                         'angle_compensate': angle_compensate}],
            output='screen')
    actions.append(lidar1)

    lidar2 = Node(
            package = "tf2_ros",
            executable = "static_transform_publisher",
            arguments = ["-0.028", "0", "0.051", "3.1", "0", "0", "plate_2_link", "rplidar"])
    actions.append(lidar2)

    actions.append(DeclareLaunchArgument(
        'channel_type',
        default_value='serial',
        description='Specifying channel type of lidar'))

    actions.append(DeclareLaunchArgument(
        'serial_port',
        default_value='/dev/rplidar',
        description='Specifying usb port to connected lidar'))

    actions.append(DeclareLaunchArgument(
        'serial_baudrate',
        default_value='115200',
        description='Specifying usb port baudrate to connected lidar'))

    actions.append(DeclareLaunchArgument(
        'frame_id',
        default_value='rplidar',
        description='Specifying frame_id of lidar'))

    actions.append(DeclareLaunchArgument(
        'inverted',
        default_value='false',
        description='Specifying whether or not to invert scan data'))

    actions.append(DeclareLaunchArgument(
        'angle_compensate',
        default_value='true',
        description='Specifying whether or not to enable angle_compensate of scan data'))

    actions.append(DeclareLaunchArgument(
        'scan_mode',
        default_value='Sensitivity',
        description='Specifying scan mode of lidar'))

    #! ------------- TELEOP MUX TB ------------------
    mux_node = Node(
            package='topic_tools', executable='mux', name='cmd_mux',
            parameters=[
                {'output_topic': '/cmd_mux/obstacle'},
                {'input_topics': ['/teleop/twistCommand','/mux/autoCommand']},
                ],
            output='screen')
    actions.append(mux_node)

    teleop_node = Node(
            package='vrep_ros_teleop', executable='teleop_node', name='teleop',
            parameters=[
                {'~/axis_linear_x': 1},
                {'~/axis_angular': 0},
                {'~/scale_linear_x': 0.15},
                {'~/scale_angular': 1.0},
                {'~/timeout': 1.0}
                ],
            remappings=[
                ('twistCommand', '/teleop/twistCommand'),
                ],
            output='screen')
    actions.append(teleop_node)

    teleop_mux_node = Node(
            package='vrep_ros_teleop', executable='teleop_mux_node', name='teleop_mux',
            parameters=[
                {'~/joystick_button': 0},
                {'~/joystick_topic': '/teleop/twistCommand'},
                {'~/auto_button': 1},
                {'~/auto_topic': '/mux/autoCommand'}
                ],
            remappings=[
                ('select', '/cmd_mux/select'),
                ],
            output='screen')
    actions.append(teleop_mux_node)

    #!---------------------- FLOOR NAV ----------------------------
    floor_nav_node = Node(
    package='floor_nav', executable='floornav_task_server', name='floor_tasks',
    parameters=[
        {'lib_path': os.path.join(os.getenv("HOME"),"turtlebot06_ws/install/floor_nav/lib/floor_nav")},
        {'base_frame': 'base_link'},
        {'reference_frame': 'map'},
        ],
    remappings=[
        #('~/clouds3d', '/points'),
        ('~/scans', '/scan'),
        ('/mux/autoCommand', '/mux/autoCommand'),
        ],
    output='screen')
    actions.append(floor_nav_node)

    #!------------- AUTODOCK LAUNCH ------------------
    # package root
    share_dir = ament_index_python.packages.get_package_share_directory('kobuki_auto_docking')

    # kobuki_auto_docking
    params_file = os.path.join(share_dir, 'config', 'auto_docking.yaml')

    with open(params_file, 'r') as f:
        params = yaml.safe_load(f)['kobuki_auto_docking']['ros__parameters']

    kobuki_auto_docking_node = ComposableNode(
        package='kobuki_auto_docking',
        plugin='kobuki_auto_docking::AutoDockingROS',
        name='kobuki_auto_docking',
        remappings=[
            ('/commands/velocity','mux/autoCommand'),
        ],
        parameters=[params]
    )

    # packs to the container
    autodock_node = ComposableNodeContainer(
            name='mobile_base_container',
            namespace='',
            package='rclcpp_components',
            executable='component_container',
            composable_node_descriptions=[
                kobuki_auto_docking_node
            ],
            output='both',)
    actions.append(autodock_node)

    #!------------- TURTLEBOT DESCRIPTION LAUNCH ------------------
    turtlebot_description = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory('turtlebot_launch'),
                'turtlebot_description.launch.py'
            )
        )
    )
    actions.append(turtlebot_description)


    actions.append(ExecuteProcess(
    cmd=['python3', 'src/floor_nav/missions/final_mission.py'],
    output='screen'
    )
)

    return LaunchDescription(actions)
