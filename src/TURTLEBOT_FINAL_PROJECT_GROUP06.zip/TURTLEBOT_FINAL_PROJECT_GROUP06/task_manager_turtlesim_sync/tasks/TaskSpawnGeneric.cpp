#include "TaskSpawnGeneric.h"
using namespace task_manager_turtlesim_sync;

DYNAMIC_TASK(TaskFactorySpawn)
