#!/bin/bash


ros2 action send_goal /auto_docking_action kobuki_ros_interfaces/action/AutoDocking "{}"


