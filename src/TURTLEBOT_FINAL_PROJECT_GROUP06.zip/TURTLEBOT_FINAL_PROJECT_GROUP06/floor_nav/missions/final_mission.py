#!/usr/bin/env python3

import rclpy
import sys
import tf2_ros 
from std_msgs.msg import Bool
from std_srvs.srv import SetBool
from rclpy.node import Node
from time import sleep
from task_manager_client_py.TaskClient import *
from tf2_ros import TransformException
from rclpy.time import Time
from rclpy.duration import Duration

exploration_status = False
map_discovered = False

def map_discovered_cb(msg):
    global map_discovered
    map_discovered=msg.data
    if map_discovered: 
        node.get_logger().info("Map is discovered")

def get_current_pose(tf_buffer, node):
    """Get the current position of the robot to be able to go back to the dock"""
    node.get_logger().info("Waiting for transform (map → base_link)")
    
    #! Wait for the transform to become available
    for _ in range(20):  #! 20 seconds to try to get the transform
        try:
            #! Use the latest available transform
            t = tf_buffer.lookup_transform(
                "map",  
                "base_link", 
                rclpy.time.Time(), 
                timeout=Duration(seconds=1.0)
            )
            
            x = t.transform.translation.x
            y = t.transform.translation.y
            node.get_logger().info(f"Transform received: (x: {x:.2f}, y: {y:.2f})")
            return (x, y)
        except TransformException as e:
            node.get_logger().warn(f"Waiting for transform attempt {_+1}")
            rclpy.spin_once(node, timeout_sec=0.1)
            continue
    
    node.get_logger().error("Transform lookup failed after multiple attempts")
    return None


def main():
    #!  Initialize rclpy and node
    global node, exploration_status , map_discovered
    rclpy.init(args=sys.argv)
    node = Node('my_node')
    
    #! Subscriber for completion of map
    map_sub = node.create_subscription(Bool,'/occgrid_planner/map_discovered',map_discovered_cb,1)

    #! Initialize TF2 listener with larger buffer time
    tf_buffer = tf2_ros.Buffer(cache_time=Duration(seconds=10.0))
    tf_listener = tf2_ros.TransformListener(tf_buffer, node)
    
    #! Initialize TaskClient
    tc = TaskClient('/floor_tasks', 0.2)
    
    try:
        clock = node.get_clock()
        initial_time = clock.now().nanoseconds / 1e9
        
        #! Wait briefly to ensure TF system is ready
        rclpy.spin_once(node, timeout_sec=1.0)
        
        node.get_logger().info("Starting undocking")
        tc.Undocking()
        
        #! Wait a moment after undocking before getting pose
        tc.Wait(duration=2.0)

        #! Get current pose in map frame
        pose = get_current_pose(tf_buffer, node)
        
        if pose is None:
            node.get_logger().error("Failed to get robot pose. Exiting.")
            return

        x, y = pose
        node.get_logger().info(f"Stored return position: x={x:.2f}, y={y:.2f}")

        tc.Wait(duration=1.0)

        node.get_logger().info("Starting exploration")
        exploration_status=True
        tc.SetBool(service_name="activate_exploration", value=True)
        
        #! Main exploration loop
        elapsed = 0.0
        while exploration_status and elapsed < 600 and map_discovered==False:
            rclpy.spin_once(node, timeout_sec=1.0)
            elapsed = (clock.now().nanoseconds / 1e9) - initial_time

        tc.SetBool(service_name="activate_exploration", value=False)
        tc.Wait(duration=8.0)
        #! Return to stored position
        node.get_logger().info("Returning to docking position")
        tc.PlanTo(goal_x=x, goal_y=y)
        
        #! Dock
        node.get_logger().info("Attempting to dock")
        tc.AutoDock()

    except TaskException as e:
        node.get_logger().error(f"Task Exception caught: {str(e)}")
    except Exception as e:
        node.get_logger().error(f"Unexpected error: {str(e)}")
    finally:
        node.get_logger().info("Final Mission completed")
        rclpy.shutdown()


if __name__ == '__main__':
    main()