#ifndef TASK_UNDOCKING_H
#define TASK_UNDOCKING_H

#include "task_manager_lib/TaskInstance.h"
#include "floor_nav/SimTasksEnv.h"
#include "std_msgs/msg/bool.hpp"

using namespace task_manager_lib;

namespace floor_nav {

struct TaskUndockingConfig : public TaskConfig {
TaskUndockingConfig() {
define("goal_x_undocking1", -1.2, "Backward motion distance for phase 1 (in meters)", false, goal_x_undocking1);
define("goal_x_undocking2", -0.5, "Backward motion distance for phase 3 (in meters)", false, goal_x_undocking2);
define("k_v", 0.5, "Gain for velocity control", false, k_v);
define("k_alpha", 1.0, "Gain for angular control", false, k_alpha);
define("max_velocity", 1.0, "Maximum allowed linear velocity", false, max_velocity);
define("max_angular_velocity", 1.0, "Maximum allowed angular velocity", false, max_angular_velocity);
define("dist_threshold", 0.1, "Distance threshold to consider position target reached", false, dist_threshold);
define("rot_threshold", 0.1, "Angular threshold (radians) to consider rotation complete", false, rot_threshold);
}


double goal_x_undocking1, goal_x_undocking2;
double k_v, k_alpha;
double max_velocity;
double max_angular_velocity;
double dist_threshold;
double rot_threshold;
};


class TaskUndocking : public TaskInstance<TaskUndockingConfig, SimTasksEnv>
{
protected:
double x_init, target_x_1, target_x_2;
double theta_init, target_theta_;
bool phase1, phase2, phase3;
rclcpp::Publisher<std_msgs::msg::Bool>::SharedPtr done_pub_;

public:
TaskUndocking(TaskDefinitionPtr def, TaskEnvironmentPtr env) : Parent(def, env) {}
virtual ~TaskUndocking() {}

virtual TaskIndicator initialise();

virtual TaskIndicator iterate();

virtual TaskIndicator terminate();
};


class TaskFactoryUndocking : public TaskDefinition<TaskUndockingConfig, SimTasksEnv, TaskUndocking>
{
public:
TaskFactoryUndocking(TaskEnvironmentPtr env) :
Parent("Undocking", "Undocking: move backward to detach from charger", true, env) {}
virtual ~TaskFactoryUndocking() {}
};

};

#endif // TASK_UNDOCKING_H