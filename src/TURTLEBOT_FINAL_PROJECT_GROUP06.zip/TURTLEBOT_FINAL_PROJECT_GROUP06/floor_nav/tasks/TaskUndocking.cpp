#include <math.h>
#include "TaskUndocking.h"

using namespace task_manager_msgs;
using namespace task_manager_lib;
using namespace floor_nav;

TaskIndicator TaskUndocking::initialise()
{
RCLCPP_INFO(getNode()->get_logger(), "Initializing undocking maneuver");

const geometry_msgs::msg::Pose2D & tpose = env->getPose2D();
x_init = tpose.x; //! Store initial position
theta_init = tpose.theta; //! Store initial orientation

target_x_1 = x_init + cfg->goal_x_undocking1; //! Target after first backward motion (1 m)
target_x_2 = x_init + cfg->goal_x_undocking2;
phase1 = false; //! Initial backward motion phase
phase2 = false; //! Rotation phase
phase3 = false; //! Final backward motion phase

done_pub_ = getNode()->create_publisher<std_msgs::msg::Bool>("/undocking_done", 10);

return TaskStatus::TASK_INITIALISED;
}

TaskIndicator TaskUndocking::iterate()
{
const geometry_msgs::msg::Pose2D & tpose = env->getPose2D();

//!  PHASE 1: Backward motion (1 m) 
if (!phase1) {
double dx = target_x_1 - tpose.x;
double r = fabs(dx);
RCLCPP_INFO(getNode()->get_logger(), "Phase 1 - Current X: %.3f, Target X: %.3f, dx: %.3f", tpose.x, target_x_1, dx);

if (r > cfg->dist_threshold) {
double vel = std::clamp(cfg->k_v * dx, -cfg->max_velocity, cfg->max_velocity);
env->publishVelocity(vel, 0);
return TaskStatus::TASK_RUNNING;
} else {
env->publishVelocity(0, 0);
target_theta_ = remainder(theta_init + M_PI, 2 * M_PI); //! Set 180° rotation target
phase1 = true; 
RCLCPP_INFO(getNode()->get_logger(), "Phase 1 complete. Starting 180° rotation.");
return TaskStatus::TASK_RUNNING;
}
}

//!  PHASE 2: Rotation 180° 
if (phase1 && !phase2) {
double angle_error = remainder(target_theta_ - tpose.theta, 2 * M_PI);
if (fabs(angle_error) < cfg->rot_threshold) {
env->publishVelocity(0, 0);
phase2 = true; 
RCLCPP_INFO(getNode()->get_logger(), "Phase 2 complete. Starting final backward motion (0.5 m).");
return TaskStatus::TASK_RUNNING;
} else {
double rot = std::clamp(cfg->k_alpha * angle_error, -cfg->max_angular_velocity, cfg->max_angular_velocity);
env->publishVelocity(0, rot);
return TaskStatus::TASK_RUNNING;
}
}

//!  PHASE 3: Backward motion (0.5 m) 
if (phase2 && !phase3) {
double dx2 = target_x_2 - tpose.x;
double r2 = fabs(dx2);

RCLCPP_INFO(getNode()->get_logger(), "Phase 1 - Current X: %.3f, Target X: %.3f, dx: %.3f", tpose.x, target_x_2, dx2);

if (r2 > cfg->dist_threshold) {
double vel = std::clamp(-cfg->max_velocity, -cfg->max_velocity, cfg->max_velocity);
env->publishVelocity(vel, 0);
return TaskStatus::TASK_RUNNING;
} else {
env->publishVelocity(0, 0);
phase3 = true;
std_msgs::msg::Bool done_msg;
done_msg.data = true;
done_pub_->publish(done_msg);

return TaskStatus::TASK_COMPLETED;
}
}

return TaskStatus::TASK_RUNNING;
}

TaskIndicator TaskUndocking::terminate()
{
//! Stop everything if task is terminated
env->publishVelocity(0, 0);
return TaskStatus::TASK_TERMINATED;
}

DYNAMIC_TASK(TaskFactoryUndocking);