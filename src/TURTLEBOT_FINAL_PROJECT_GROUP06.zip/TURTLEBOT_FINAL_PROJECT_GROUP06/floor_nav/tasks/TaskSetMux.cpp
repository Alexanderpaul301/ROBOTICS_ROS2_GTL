#include "TaskSetMux.h"
using namespace floor_nav;

DYNAMIC_TASK(TaskFactorySetMux)
