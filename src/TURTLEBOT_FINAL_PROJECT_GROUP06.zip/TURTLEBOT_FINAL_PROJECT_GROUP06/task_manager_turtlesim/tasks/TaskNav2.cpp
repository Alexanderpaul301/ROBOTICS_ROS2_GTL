
#include "TaskNav2.h"
using namespace task_manager_turtlesim;

DYNAMIC_TASK(TaskFactoryNav2)
