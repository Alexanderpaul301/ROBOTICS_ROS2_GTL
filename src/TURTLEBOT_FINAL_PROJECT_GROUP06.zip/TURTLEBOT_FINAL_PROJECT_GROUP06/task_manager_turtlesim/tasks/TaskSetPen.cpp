#include <math.h>
#include "TaskSetPen.h"
using namespace task_manager_turtlesim;


DYNAMIC_TASK(TaskFactorySetPen)
