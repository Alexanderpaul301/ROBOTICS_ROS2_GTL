#include <stdio.h>
#include <boost/version.hpp>

int main() {
    printf("Boost version: %08d\n",BOOST_VERSION);
    return 0;
}

