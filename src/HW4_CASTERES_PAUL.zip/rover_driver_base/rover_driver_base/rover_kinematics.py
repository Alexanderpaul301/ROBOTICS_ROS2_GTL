#!/usr/bin/env python
from geometry_msgs.msg import Twist
import numpy as np
from numpy.linalg import pinv
from math import atan2, hypot, pi, cos, sin

prefix=["FL","FR","CL","CR","RL","RR"]

class RoverMotors:
    def __init__(self):
        self.steering={}
        self.drive={}
        for k in prefix:
            self.steering[k]=0.0
            self.drive[k]=0.0
    def copy(self,value):
        for k in prefix:
            self.steering[k]=value.steering[k]
            self.drive[k]=value.drive[k]

class DriveConfiguration:
    def __init__(self,radius,x,y,z):
        self.x = x
        self.y = y
        self.z = z
        self.radius = radius


class RoverKinematics:
    def __init__(self):
        self.X = np.asmatrix(np.zeros((3,1)))
        self.motor_state = RoverMotors()
        self.ICR = (pi/2,pi/2)
        self.first_run = True

    def ICR_cart_to_polar(x,y):
        return (atan2(y,x), atan(hypot(y,x)))

    def ICR_polar_to_cart(theta,phi):
        r = tan(phi)
        return (r*cos(theta),r*sin(theta))

    def ICR_from_twist(vx,vy,wz):
        theta=atan2(vy,vx)+pi/2
        phi=atan2(hypot(vx,vy),wz)
        return (theta,phi)

    def ICR_to_twist(theta,phi,v):
        r = tan(phi)
        T = Twist()
        T.angular.z = v / r
        T.linear.x = v * cos(theta-pi/2)
        T.linear.y = v * sin(theta-pi/2)
        return T

    def filter_twist(self, twist_in, drive_cfg):
        twist_out = Twist()
        vx = twist_in.linear.x; vy = twist_in.linear.y; wz = twist_in.angular.z
        v = hypot(vx,vy)
        if abs(v)<1e-2:
            # not moving while not changing the current ICR
            theta,phi = self.ICR
            return ICR_to_twist(theta,phi,1e-3)
        elif abs(wz)<1e-2:
            pass
        else:
            pass
        return twist_out

    def twist_to_motors(self, twist, drive_cfg, skidsteer=False, drive_state=None):
        motors = RoverMotors()
        if skidsteer:
            for k in drive_cfg.keys():
                # TODO: In case we are in skidsteer mode (driving like a tank)
                # Insert here the steering and velocity of 
                # each wheel in skid-steer mode
                motors.drive[k] = (twist.linear.x - twist.angular.z*drive_cfg['C'+k[1]].y)/drive_cfg['C'+k[1]].radius 
                motors.steering[k] = 0
        else:
            for k in drive_cfg.keys():
                # TODO: In case we are in rolling without slipping mode (driving normally)
                # Insert here the steering and velocity of 
                # each wheel in rolling-without-slipping mode
                v_x = (twist.linear.x - twist.angular.z*drive_cfg[k].y)
                v_y = (twist.linear.y + twist.angular.z*drive_cfg[k].x)


                motors.drive[k] = hypot(v_y,v_x)/drive_cfg[k].radius
                motors.steering[k] = atan2(v_y,v_x)
        return motors

    def prepare_inversion_matrix(self,drive_cfg):
        # TODO: Build pseudo inverse of W using the notation from the class. The matrix size below is wrong.
        n = len(prefix);
        W = np.asmatrix(np.zeros((2*n,3)))
        # Building the W matrix, hopefully it is in the right coordinate frame  # ! (maybe change it)
        for i in range(2*n):
            if i%2==0:
                W[i,0] = 1.0
                W[i,1] = 0.0
                W[i,2] = -drive_cfg[prefix[i//2]].y
            else :
                W[i,0] = 0.0
                W[i,1] = 1.0
                W[i,2] = drive_cfg[prefix[i//2]].x
                
        iW = pinv(W)
        print("iW",np.shape(iW))
        return iW

    def prepare_displacement_matrix(self, motor_state_t1, motor_state_t2, drive_cfg):
        # then compute odometry using least square
        # TODO: Build S using the notation from the class. The matrix size below is wrong.
        n = len(prefix); # n = 6 here
        
        beta=np.asmatrix(np.zeros((n,1)))
        # Building beta (We want the angle to be in between -pi and pi) # ! Potentially a problem if the angle is in radius
        for i in range(n): 
            print(motor_state_t2.steering[prefix[i]])
            beta_temp = (motor_state_t2.steering[prefix[i]] + motor_state_t1.steering[prefix[i]])*1/2
            if np.abs(beta_temp)>pi:
                beta_temp = beta_temp - 2*pi*beta_temp/np.abs(beta_temp)
                beta[i,0] = beta_temp

            else :
                beta[i,0] = beta_temp
        
        # Building linear displacement
        dS=np.asmatrix(np.zeros((n,1)))
        for i in range(n):
            dS[i,0] = drive_cfg[prefix[i]].radius*(motor_state_t2.drive[prefix[i]] - motor_state_t1.drive[prefix[i]])

        # Building S
        S=np.asmatrix(np.zeros((2*n,1)))
        for i in range(0,2*n,2):
            S[i,0] = dS[i//2,0]*(np.cos(beta[i//2,0]))
            S[i+1,0]= dS[i//2,0]*(np.sin(beta[i//2,0]))
        
        return S

    def compute_displacement(self, motor_state, drive_cfg):
        # The first time, we need to initialise the state
        if self.first_run:
            self.motor_state.copy(motor_state)
            self.first_run = False
            return np.asmatrix(np.zeros((3,1)))
        # then compute odometry using least square
        # We assume that S = W * dX, hence dX = iW * S, where iW is the pseudo inverse of W
        # TODO: First compute iW based on the wheel positions given in drive_cfg
        iW = self.prepare_inversion_matrix(drive_cfg)
        # TODO: Then compute the displacement matrix S based on the current motor_state, and the previous one stored in self.motor_state
        S = self.prepare_displacement_matrix(self.motor_state,motor_state,drive_cfg)
        # Finally the displacement in the local frame is the product
        dX = iW * S 
        # And we backup the current motor state
        self.motor_state.copy(motor_state)
        return dX

    def integrate_odometry(self, motor_state, drive_cfg):
        # First compute the local displacement in the robot frame
        dX = self.compute_displacement(motor_state,drive_cfg)
        # TODO: Now integrate the local displacement in the global frame
        # ! Need to pass from local to global frame 
        # Define Rotation matrix
        R=np.asmatrix(np.zeros((3,3)))
        R[0,0] = cos(self.X[2,0])
        R[0,1] = -sin(self.X[2,0])
        R[1,0] = sin(self.X[2,0])
        R[1,1] = cos(self.X[2,0])
        R[2,2] = 1.0
        dX = R*dX
        self.X[0,0] += dX[0,0]
        self.X[1,0] += dX[1,0]
        self.X[2,0] += dX[2,0]
        return self.X



def quaternion_from_euler(ai, aj, ak):
    ai /= 2.0
    aj /= 2.0
    ak /= 2.0
    ci = cos(ai)
    si = sin(ai)
    cj = cos(aj)
    sj = sin(aj)
    ck = cos(ak)
    sk = sin(ak)
    cc = ci*ck
    cs = ci*sk
    sc = si*ck
    ss = si*sk

    q = np.empty((4, ))
    q[0] = cj*sc - sj*cs
    q[1] = cj*ss + sj*cc
    q[2] = cj*cs - sj*sc
    q[3] = cj*cc + sj*ss

    return q

